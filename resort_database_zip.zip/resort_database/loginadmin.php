<?php include('serveradmin.php'); ?>
<!DOCTYPE html>
<html>
<head>
    <title> ADMIN REGISTER </title>
    <link rel="stylesheet" type="text/css" href="registers.css">
</head>
<body>
    <div class="header">
        <h2>Login</h2>
    </div>  
    <form method="post" action="loginadmin.php">
                <!-- display validation errors here -->
                <?php include('errors.php'); ?> 
        <div class="input-group">
            <label>Username</label>
            <input type="text" name="username">
        </div> 
        <div class="input-group">
            <label>Password</label>
            <input type="password" name="password">
        </div>    
        <div class="input-group">
            <button type="submit" name="login" class="btn">Log In</button>
        </div>     
    </form>    





</body>
</html>