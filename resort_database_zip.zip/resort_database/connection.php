<?php

$servername = "localhost";
$username = "root";
$password ="";
$dbname ="resort_database";

$conn = mysqli_connect($servername,$username,$password,$dbname);


?>